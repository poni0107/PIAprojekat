<?php
$msg = "";

include_once("php/funkcije.php");

if(!User::isLoggedIn()){
    header("location: index.php");
    die();
}

$user = User::getCurrentUser();

if(isset($_GET["id"]) && isset($_POST["obrisi"]) && $user->getRole()=="administrator"){
    $id = UserInput::sanitize($_GET["id"]);
    $image = Image::getById($id);
    $id_delete = UserInput::sanitize($_POST["obrisi"]);
    $img = Image::getById($id_delete);
    $image->delete();
}

//obrisiKomentar
if(isset($_GET["id"]) && isset($_POST["obrisiKomentar"]) && $user->getRole()=="administrator"){
    $id = UserInput::sanitize($_GET["id"]);
    $image = Image::getById($id);
    $id_delete = UserInput::sanitize($_POST["obrisiKomentar"]);
    Image::obrisiKomentar($id_delete);
}

if(isset($_GET["id"])) {
    $id = UserInput::sanitize($_GET["id"]);
    $image = Image::getById($id);

    if(isset($_POST["addComment"])){
        $image_id = UserInput::sanitize($_POST["addComment"]);
        $user_id = $user->getId();
        $comment = UserInput::sanitize($_POST["comment"]);
        $image->addComment($user_id,$comment);
    }

    if(isset($_POST["favoritesAdd"])){
        $image->addToFavorites($user->getId());
    }

    if(isset($_POST["favoritesRemove"])){
        $image->removeFromFavorites($user->getId());
    }
}







?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <?php include_once("php/navigacija.php"); ?>
        </div>
    </div>

    <div class="row">
        <div class="col-12 text-center">
            <?php echo $msg; ?>
        </div>
    </div>

    <div class="row">
        <div class="col-12 text-center mb-5">
            <?php
                if(isset($_GET["id"])){
                    $id = UserInput::sanitize($_GET["id"]);
                    if($image!=null){
                        $user_id = $image->getUserId();
                        $user_posted = User::getById($user_id);

                        ?>
                            <img src="<?php echo "uploads/".$image->getFile(); ?>" width="600" class="mx-auto">
                            <hr>
                            <p>deli</p>
                            <button class="btn btn-primary" onclick="shareOnFacebook('<?php echo "uploads/".htmlentities($image->getFile()); ?>')">Facebook</button>
                            <button class="btn btn-info" onclick="shareOnTwitter('<?php echo "uploads/".htmlentities($image->getFile()); ?>')">Twitter</button>
                            <button class="btn btn-danger" onclick="shareOnInstagram('<?php echo "uploads/".htmlentities($image->getFile()); ?>')">Instagram</button>
                            <hr>
                            <p>
                                <?php echo $image->getDescription(); ?>
                            </p>
                            <p>
                                broj pregleda: <b><?php echo $image->getBrojPregleda(); ?></b>
                            </p>
                        <p>
                            <i>
                                Autor: <?php echo $user_posted->getUsername(); ?>
                            </i>
                        </p>
                        <?php

                        if(!$image->isInFavorites($user->getId())){
                            ?>
                                <form action="slika.php?id=<?php echo $_GET["id"]; ?>" method="post">
                                    <button type="submit" name="favoritesAdd" value="" class="btn btn-success">dodaj u omiljene</button>
                                </form>
                            <?php
                        }else{
                            ?>
                            <form action="slika.php?id=<?php echo $_GET["id"]; ?>" method="post">
                                <button type="submit" name="favoritesRemove" value="" class="btn btn-danger">ukloni iz omiljenih</button>
                            </form>
                            <?php
                        }

                        if($user->getRole()=="administrator"){
                            ?>
                            <form action="slika.php?id=<?php echo $_GET["id"]; ?>" method="post">
                                <button type="submit" name="obrisi" value="" class="btn btn-danger">obrisi</button>
                            </form>
                            <?php
                        }

                        $image->incrementBrojPregleda();

                        if($user->getRole()=="korisnik" || $user->getRole()=="administrator" || $user->getRole()=="umetnik"){
                            if($image->userGradedAlready($user->getId())){
                                $grade = $image->getGrade($user->getId());
                            }else{
                                $grade = 0;
                            }

                            ?>
                                <hr>
                                <p class="text-center">dodajte ocenu</p>
                                <button class="ocena btn <?php echo ($grade == "1") ? "btn-danger" : "btn-outline-danger"; ?>" data-image="<?php echo $image->getId(); ?>" value="1" style="width: 40px; height: 40px;">
                                    1
                                </button>
                                <button class="ocena btn <?php echo ($grade == "2") ? "btn-warning" : "btn-outline-warning"; ?>" data-image="<?php echo $image->getId(); ?>" value="2" style="width: 40px; height: 40px;">
                                    2
                                </button>
                                <button class="ocena btn <?php echo ($grade == "3") ? "btn-secondary" : "btn-outline-secondary"; ?>" data-image="<?php echo $image->getId(); ?>" value="3" style="width: 40px; height: 40px;">
                                    3
                                </button>
                                <button class="ocena btn <?php echo ($grade == "4") ? "btn-primary" : "btn-outline-primary"; ?>" data-image="<?php echo $image->getId(); ?>" value="4" style="width: 40px; height: 40px;">
                                    4
                                </button>
                                <button class="ocena btn <?php echo ($grade == "5") ? "btn-success" : "btn-outline-success"; ?>" data-image="<?php echo $image->getId(); ?>" value="5" style="width: 40px; height: 40px;">
                                    5
                                </button>

                                <p>Ocena: <?php echo $image->getAverageGrade(); ?></p>

                                <hr>
                                <p class="text-center">komentari</p>

                                <?php
                                    $comments = $image->getAllComments();

                                    foreach ($comments as $comment){
                                        ?>
                                        <div class="card mb-3">
                                            <div class="card-body">
                                                <h5 class="card-title"><?php echo User::getById($comment["user_id"])->getUsername(); ?></h5>
                                                <p class="card-text"><?php echo $comment["comment"]; ?></p>
                                                <p class="card-text"><small class="text-muted">Objavljeno: <?php echo $comment["posted"]; ?></small></p>

                                                <?php
                                                if($user->getRole()=="administrator"){
                                                    ?>
                                                    <form action="slika.php?id=<?php echo $_GET["id"]; ?>" method="post">
                                                        <button type="submit" name="obrisiKomentar" value="<?php echo $comment["id"]; ?>" class="btn btn-danger">obrisi komentar</button>
                                                    </form>
                                                    <?php
                                                }
                                                ?>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                ?>

                                <form id="commentForm" action="slika.php?id=<?php echo $_GET["id"]; ?>" method="post">
                                    <div class="mb-3">
                                        <label for="comment" class="form-label">Komentar:</label>
                                        <textarea class="form-control" id="comment" name="comment" rows="3" required></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-primary" name="addComment" value="<?php echo $image->getId(); ?>">Dodaj komentar</button>
                                </form>

                            <?php
                        }
                    }
                }
            ?>
        </div>
    </div>



</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/script.js"></script>
</body>
</html>
