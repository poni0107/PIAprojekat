var ocena = document.getElementsByClassName("ocena");

for(var i=0;i<ocena.length;i++){
    ocena[i].addEventListener("click",(e)=>{
        var grade = e.target.value;
        var image_id = e.target.getAttribute("data-image");

        var xmlhttp = new XMLHttpRequest();

        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == XMLHttpRequest.DONE) { // XMLHttpRequest.DONE == 4
                if (xmlhttp.status == 200) {
                    var response = xmlhttp.responseText;
                    if(response=="ok"){
                        document.location.reload();
                    }
                }
            }
        };

        xmlhttp.open("GET", "php/ajax.php?grade="+grade+"&image_id="+image_id, true);
        xmlhttp.send();
    });
}

function shareOnFacebook(imageUrl) {
    // Zamijenite YOUR_IMAGE_URL sa URL-om slike koju želite deliti
    window.open('https://www.facebook.com/sharer/sharer.php?u=' + encodeURIComponent(imageUrl), '_blank');
}

function shareOnTwitter(imageUrl) {
    // Zamijenite YOUR_IMAGE_URL sa URL-om slike koju želite deliti
    window.open('https://twitter.com/intent/tweet?url=' + encodeURIComponent(imageUrl), '_blank');
}

function shareOnInstagram(imageUrl) {
    // Zamijenite YOUR_IMAGE_URL sa URL-om slike koju želite deliti
    // Otvorite Instagram u novom prozoru ili preusmerite korisnika na Instagram
    window.open('https://www.instagram.com', '_blank');
    // Napomena: Instagram ograničava mogućnost automatskog postavljanja slika putem URL-a
    // pa korisnik mora ručno postaviti sliku nakon što se otvori Instagram.
}

