DROP DATABASE IF EXISTS `izlozba-slika`;
CREATE DATABASE `izlozba-slika`;
USE `izlozba-slika`;

CREATE TABLE users
(
    id       INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255)                                  NOT NULL,
    password VARCHAR(255)                                  NOT NULL,
    email    VARCHAR(255)                                  NOT NULL,
    role     ENUM ('korisnik', 'umetnik', 'administrator') NOT NULL,
    status   ENUM ('active', 'blocked')                    NOT NULL
);

#lozinka pass
INSERT INTO users (username, password, email, role, status)
VALUES ('korisnik1', '$2y$10$DGUcpxtTdmI62AMInE.k2elTp06SUHJE3sCOgu1AyiJwEEXR2jBQ2', 'korisnik1@example.com',
        'korisnik', 'active'),
       ('korisnik2', '$2y$10$DGUcpxtTdmI62AMInE.k2elTp06SUHJE3sCOgu1AyiJwEEXR2jBQ2', 'korisnik2@example.com',
        'korisnik', 'active'),
       ('umetnik1', '$2y$10$DGUcpxtTdmI62AMInE.k2elTp06SUHJE3sCOgu1AyiJwEEXR2jBQ2', 'umetnik1@example.com', 'umetnik',
        'active'),
       ('umetnik2', '$2y$10$DGUcpxtTdmI62AMInE.k2elTp06SUHJE3sCOgu1AyiJwEEXR2jBQ2', 'umetnik2@example.com', 'umetnik',
        'active'),
       ('admin1', '$2y$10$DGUcpxtTdmI62AMInE.k2elTp06SUHJE3sCOgu1AyiJwEEXR2jBQ2', 'admin1@example.com', 'administrator',
        'active'),
       ('admin2', '$2y$10$DGUcpxtTdmI62AMInE.k2elTp06SUHJE3sCOgu1AyiJwEEXR2jBQ2', 'admin2@example.com', 'administrator',
        'active'),
       ('blokiran1', '$2y$10$DGUcpxtTdmI62AMInE.k2elTp06SUHJE3sCOgu1AyiJwEEXR2jBQ2', 'blokiran1@example.com',
        'korisnik', 'blocked'),
       ('blokiran2', '$2y$10$DGUcpxtTdmI62AMInE.k2elTp06SUHJE3sCOgu1AyiJwEEXR2jBQ2', 'blokiran2@example.com', 'umetnik',
        'blocked'),
       ('blokiran3', '$2y$10$DGUcpxtTdmI62AMInE.k2elTp06SUHJE3sCOgu1AyiJwEEXR2jBQ2', 'blokiran3@example.com',
        'administrator', 'active'),
       ('korisnik3', '$2y$10$DGUcpxtTdmI62AMInE.k2elTp06SUHJE3sCOgu1AyiJwEEXR2jBQ2', 'korisnik3@example.com',
        'korisnik', 'active');

CREATE TABLE image
(
    id           INT AUTO_INCREMENT PRIMARY KEY,
    fajl         VARCHAR(255) NOT NULL,
    opis         TEXT,
    user_id      INT,
    brojPregleda INT DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users (id)
);

INSERT INTO image (fajl, opis, user_id, brojPregleda)
VALUES ('658436b894b61_Screenshot (14).png', 'Opis slike 1', 3, 0),
       ('658437d0eb1d6_Screenshot (13).png', 'Opis slike 2', 3, 0),
       ('6584339f0d011_Screenshot (6).png', 'Opis slike 3', 3, 0),
       ('6584352d59994_Screenshot (14).png', 'Opis slike 4', 4, 0),
       ('6584355b6f588_Screenshot (6).png', 'Opis slike 5', 3, 0),
       ('6584369be2ffd_Screenshot (12).png', 'Opis slike 6', 4, 0),
       ('65843496c240c_Screenshot (14).png', 'Opis slike 7', 4, 0),
       ('65843794b1d56_Screenshot (12).png', 'Opis slike 8', 3, 0),
       ('658435962c3b8_Screenshot (14).png', 'Opis slike 9', 3, 0)

CREATE TABLE rating
(
    id       INT AUTO_INCREMENT PRIMARY KEY,
    image_id INT,
    user_id  INT,
    grade    INT CHECK (grade >= 1 AND grade <= 5),
    FOREIGN KEY (image_id) REFERENCES image (id),
    FOREIGN KEY (user_id) REFERENCES users (id)
);

CREATE TABLE comments
(
    id       INT AUTO_INCREMENT PRIMARY KEY,
    user_id  INT,
    image_id INT,
    comment  TEXT,
    posted   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id),
    FOREIGN KEY (image_id) REFERENCES image (id)
);

CREATE TABLE favorites
(
    id       INT AUTO_INCREMENT PRIMARY KEY,
    user_id  INT,
    image_id INT,
    FOREIGN KEY (user_id) REFERENCES users (id),
    FOREIGN KEY (image_id) REFERENCES image (id)
);
