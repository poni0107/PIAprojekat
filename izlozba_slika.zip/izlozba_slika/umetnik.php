<?php
$msg = "";

include_once("php/funkcije.php");

if(!User::isLoggedIn()){
    header("location: index.php");
    die();
}

$user = User::getCurrentUser();

if($user->getRole()!=="umetnik"){
    header("location: index.php");
    die();
}

if(isset($_POST["dodaj"])){
    $opis = UserInput::sanitize($_POST["opis"]);
    var_dump($opis);

    if (isset($_FILES['slika']) && $_FILES['slika']['error'] === UPLOAD_ERR_OK) {

        $fileName = uniqid() . '_' . $_FILES['slika']['name'];
        $msg = Image::add($fileName, $opis);


    } else {
        echo Message::danger("Molimo izaberite sliku.");
    }

}

if(isset($_GET["remove"])){
    $id = UserInput::sanitize($_GET["remove"]);

    Image::removeUserImage($id, $user->getId());
}

$images = Image::getUserImages($user->getId());

include_once("php/funkcije.php");

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <?php include_once("php/navigacija.php"); ?>
        </div>
    </div>

    <div class="row">
        <div class="col-12 text-center">
            <?php echo $msg; ?>
        </div>
    </div>

    <div class="row mt-5">
        <div class="col-6 offset-3">
            <h2>Dodaj sliku</h2>
            <form method="post" action="umetnik.php" enctype="multipart/form-data">
                <!-- Dodajte polje za unos slike -->
                <div class="mb-3">
                    <label for="slika" class="form-label">Izaberite sliku:</label>
                    <input type="file" class="form-control" id="slika" name="slika" accept="image/*" required>
                </div>

                <!-- Dodajte polje za unos opisa slike -->
                <div class="mb-3">
                    <label for="opis" class="form-label">Opis slike:</label>
                    <textarea class="form-control" id="opis" name="opis" rows="3"></textarea>
                </div>

                <button type="submit" class="btn btn-primary" name="dodaj">Dodaj sliku</button>
            </form>
        </div>
    </div>

    <div class="row">
        <div class="col-12 text-center">
            <?php
                foreach($images as $image){
                    ?>
                    <div class="card d-inline-block " style="width: 400px;">
                        <img src="uploads/<?php echo $image->getFile(); ?>" class="card-img-top" alt="...">
                        <div class="card-body">
                            <small class="card-title p"><?php echo $image->getFile(); ?></small>
                            <p class="card-text"><b>Opis</b><br><?php echo $image->getDescription(); ?></p>
                            <hr>
                            <p class="card-text"><b>broj pregleda</b><br><?php echo $image->getBrojPregleda(); ?></p>
                            <p class="card-text"><b>ocena</b><br><?php echo $image->getAverageGrade(); ?></p>

                            <a href="umetnik.php?remove=<?php echo $image->getId(); ?>" class="btn btn-danger">remove</a>

                            <?php
                            $comments = $image->getAllComments();
                            ?>

                            <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#collapseExample<?php echo $image->getId(); ?>" aria-expanded="false" aria-controls="collapseExample">
                                komentari(<?php echo count($comments); ?>)
                            </button>
                            </p>
                            <div class="collapse" id="collapseExample<?php echo $image->getId(); ?>">
                                <div class="card card-body">
                                    <?php


                                    foreach ($comments as $comment){
                                        ?>
                                        <div class="card mb-3">
                                            <div class="card-body">
                                                <p class="card-title"><?php echo User::getById($comment["user_id"])->getUsername(); ?></p>
                                                <p class="card-text"><?php echo $comment["comment"]; ?></p>
                                                <p class="card-text"><small class="text-muted">Objavljeno: <?php echo $comment["posted"]; ?></small></p>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                </div>
                            </div>


                        </div>
                    </div>
                    <?php
                }
            ?>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
