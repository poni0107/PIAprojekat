<?php
$msg = "";

include_once("php/funkcije.php");

if(!User::isLoggedIn()){
    header("location: index.php");
    die();
}

$user = User::getCurrentUser();

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <?php include_once("php/navigacija.php"); ?>
        </div>
    </div>

    <div class="row">
        <div class="col-12 text-center">
            <?php echo $msg; ?>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <?php
                $images = Image::getAllImages();
            foreach($images as $image){
                $komentari = Image::getComments($image->getId(), $user->getId())
                ?>
                <div class="card d-inline-block" style="width: 18rem;">
                    <img src="uploads/<?php echo $image->getFile(); ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <a href="slika.php?id=<?php echo $image->getId(); ?>" class="btn btn-success">vidi vise</a>
                    </div>
                </div>
                <?php
            }
            ?>
        </div>
    </div>



</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
