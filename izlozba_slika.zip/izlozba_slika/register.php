<?php
$msg = "";

include_once("php/funkcije.php");

if(isset($_POST["registracija"])){
    $username = UserInput::sanitize($_POST["username"]);
    $password = UserInput::sanitize($_POST["password"]);
    $email = UserInput::sanitize($_POST["email"]);
    $role = UserInput::sanitize($_POST["role"]);

    $msg = User::register($username, $password, $email, $role);
}

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <?php include_once("php/navigacija.php"); ?>
        </div>
    </div>

    <div class="row">
        <div class="col-12 text-center">
            <?php echo $msg; ?>
        </div>
    </div>

    <div class="row mt-5">
        <div class="col-6 offset-3">
            <h2>Registracija korisnika</h2>
            <form method="post" action="register.php">
                <!-- Dodajte polja za unos podataka -->
                <div class="mb-3">
                    <label for="username" class="form-label">Korisničko ime:</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">Lozinka:</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">E-mail adresa:</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>

                <div class="mb-3">
                    <label for="role" class="form-label">Uloga:</label>
                    <select class="form-select" id="role" name="role" required>
                        <option value="korisnik">Korisnik</option>
                        <option value="umetnik">Umetnik</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary" name="registracija">Registracija</button>
            </form>
        </div>
    </div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
