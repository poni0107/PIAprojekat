<?php

class Message {
    public static function success($txt){
        return self::generateAlert('success', $txt);
    }

    public static function danger($txt) {
        return self::generateAlert('danger', $txt);
    }

    public static function warning($txt) {
        return self::generateAlert('warning', $txt);
    }

    private static function generateAlert($type, $txt) {
        return '<div class="alert alert-' . $type . ' alert-dismissible fade show" role="alert">
              ' . $txt . '
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';
    }
}