<?php
include_once("funkcije.php");

if(isset($_GET["grade"]) && isset($_GET["image_id"]) && isset($_SESSION["user"])){
    $user = User::getCurrentUser();

    $grade = UserInput::sanitize($_GET["grade"]);
    $image_id = UserInput::sanitize($_GET["image_id"]);

    $image = Image::getById($image_id);
    echo $image->addRating($user->getId(), $grade);
    die();
}

