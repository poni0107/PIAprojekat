<?php

class Image
{
    private $id;
    private $file;
    private $description;
    private $userId;

    private $brojPregleda;

    // Konstruktor za kreiranje novog objekta slike
    public function __construct($id, $file, $description, $userId, $brojPregleda) {
        $this->id = $id;
        $this->file = $file;
        $this->description = $description;
        $this->userId = $userId;
        $this->brojPregleda = $brojPregleda;
    }

    public static function getUserImages($userId){
        $sql = "SELECT * FROM image WHERE user_id = ?";
        $params = [$userId];

        $result = Connection::getP($sql, $params);

        $images = [];
        foreach ($result as $row) {
            $images[] = new Image(
                $row['id'],
                $row['fajl'],
                $row['opis'],
                $row['user_id'],
                $row['brojPregleda']
            );
        }

        return $images;
    }

    public static function removeUserImage($id, $userId){

        // Brisanje slike
        $deleteSql = "DELETE FROM image WHERE id = ? AND user_id = ?";
        $deleteParams = [$id, $userId];

        return Connection::setP($deleteSql, $deleteParams);
    }

    public static function getComments($imageId, $userId){
        return [];
    }

    public static function add($fileName, $opis){
        $uploadDir = 'uploads/';

        // Generisanje jedinstvenog imena fajla

        $filePath = $uploadDir . $fileName;

        // Pomeranje upload-ovanog fajla u odredišni direktorijum
        if (move_uploaded_file($_FILES['slika']['tmp_name'], $filePath)) {
            // Fajl je uspešno upload-ovan

            $user_id = User::getCurrentUser()->getId();

            // SQL upit za unos podataka u tabelu "slike"
            $sql = "INSERT INTO image (fajl, opis, user_id) VALUES (?, ?, ?)";
            $params = [$fileName, $opis, $user_id];

            $success = Connection::setP($sql, $params);

            // Izvršavanje upita
            if ($success) {
                return Message::success("Slika je uspešno dodata.");
            } else {
                return Message::danger("Greška prilikom upisa u bazu: ");
            }
        } else {
            return Message::danger("Greška prilikom upload-a slike.");
        }
    }

    public function incrementBrojPregleda(){

        // Ažuriranje vrednosti u bazi podataka
        $sql = "UPDATE image SET brojPregleda = brojPregleda + 1 WHERE id = ?";
        $params = [$this->id];

        Connection::setP($sql, $params);
    }

    public function delete(){
        $sql = "DELETE FROM image WHERE id=?";
        $params = [$this->id];

        Connection::setP($sql, $params);
    }

    public function userGradedAlready($userId){
        // Provera da li korisnik već ima ocenu za odabranu sliku
        $existingSql = "SELECT * FROM rating WHERE image_id = ? AND user_id = ?";
        $existingParams = [$this->id, $userId];

        $existingResult = Connection::getP($existingSql, $existingParams);

        return $existingResult->num_rows>0;
    }

    public function getGrade($userId){
        // SQL upit za dohvatanje ocene za datog korisnika i sliku
        $sql = "SELECT grade FROM rating WHERE user_id = ? AND image_id = ?";
        $params = [$userId, $this->id];

        $result = Connection::getP($sql, $params);

        return $result->fetch_assoc()["grade"];
    }

    public function getAverageGrade()
    {
        // SQL upit za dohvatanje prosečne ocene za datu sliku
        $sql = "SELECT AVG(grade) AS average_grade FROM rating WHERE image_id = ?";
        $params = [$this->id];

        $result = Connection::getP($sql, $params);

        return $result->fetch_assoc()['average_grade'];
    }

    public function isInFavorites($userId){
        // Provera da li je slika već među omiljenima za određenog korisnika
        $checkSql = "SELECT * FROM favorites WHERE user_id = ? AND image_id = ?";
        $checkParams = [$userId, $this->id];

        $isAlreadyFavorite = Connection::getP($checkSql, $checkParams);

        return $isAlreadyFavorite->num_rows>0;
    }

    public function addToFavorites($userId)
    {
        if(!$this->isInFavorites($userId)){
            // Dodavanje slike među omiljene
            $addSql = "INSERT INTO favorites (user_id, image_id) VALUES (?, ?)";
            $addParams = [$userId, $this->id];

            $success = Connection::setP($addSql, $addParams);

            return $success;
        }
    }

    public function removeFromFavorites($userId)
    {
            // Dodavanje slike među omiljene
            $sql = "DELETE FROM favorites WHERE user_id=? AND image_id=?";
            $addParams = [$userId, $this->id];

            $success = Connection::setP($sql, $addParams);

            return $success;
    }

    public function getAllComments(){
        // SQL upit za dohvatanje svih komentara za datu sliku sa korisničkim imenom
        $sql = "
            SELECT * 
            FROM comments
            WHERE image_id = ?
        ";

        $params = [$this->id];

        $result = Connection::getP($sql, $params);

        $comments = [];

        while ($row = $result->fetch_assoc()){
            $comments[] = [
                'id' => $row['id'],
                'user_id' => $row['user_id'],
                'image_id' => $row['image_id'],
                'comment' => $row['comment'],
                'posted' => $row['posted']
            ];
        }

        return $comments;
    }

    public function addComment($user_id, $comment)
    {
        // SQL upit za dodavanje komentara u tabelu comments
        $sql = "INSERT INTO comments (user_id, image_id, comment) VALUES (?, ?, ?)";
        $params = [$user_id, $this->id, $comment];

        // Izvršavanje upita
        $success = Connection::setP($sql, $params);

        return $success;
    }

    public function addRating($userId, $grade)
    {
        if($this->userGradedAlready($userId)){
            //korisnik je vec ocenio sliku
            $sql = "UPDATE rating SET grade = ? WHERE image_id = ? AND user_id = ?";
            $params = [$grade, $this->id, $userId];

            $success = Connection::setP($sql, $params);

            // Izvršavanje upita
            if ($success) {
                return "ok";
            } else {
                return Message::danger("Greška prilikom upisa ocene u bazu.");
            }
        }else{
            // Dodavanje nove ocene
            $sql = "INSERT INTO rating (image_id, user_id, grade) VALUES (?, ?, ?)";
            $params = [$this->id, $userId, $grade];

            $success = Connection::setP($sql, $params);

            // Izvršavanje upita
            if ($success) {
                return "ok";
            } else {
                return Message::danger("Greška prilikom upisa ocene u bazu.");
            }
        }
    }

    public static function obrisiKomentar($commentId){
        $sql = "DELETE FROM comments WHERE id = ?";
        $params = [$commentId];

        Connection::setP($sql, $params);
    }

    public static function getById($id){
        $sql = "SELECT * FROM image WHERE id = ?";
        $params = [$id];

        $result = Connection::getP($sql, $params);

        if ($result->num_rows==0) {
            return null;
        }

        $row = $result->fetch_assoc();

        return new Image(
            $row['id'],
            $row['fajl'],
            $row['opis'],
            $row['user_id'],
            $row['brojPregleda']
        );
    }

    public static function getAllImages() {
        $sql = "SELECT * FROM image";
        $result = Connection::get($sql);

        $images = [];
        foreach ($result as $row) {
            $images[] = new Image(
                $row['id'],
                $row['fajl'],
                $row['opis'],
                $row['user_id'],
                $row['brojPregleda']
            );
        }

        return $images;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getFile()
    {
        return $this->file;
    }

    /**
     * @param mixed $file
     */
    public function setFile($file)
    {
        $this->file = $file;
    }

    /**
     * @return mixed
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * @param mixed $description
     */
    public function setDescription($description)
    {
        $this->description = $description;
    }

    /**
     * @return mixed
     */
    public function getUserId()
    {
        return $this->userId;
    }

    /**
     * @param mixed $userId
     */
    public function setUserId($userId)
    {
        $this->userId = $userId;
    }

    /**
     * @return mixed
     */
    public function getBrojPregleda()
    {
        return $this->brojPregleda;
    }

    /**
     * @param mixed $brojPregleda
     */
    public function setBrojPregleda($brojPregleda)
    {
        $this->brojPregleda = $brojPregleda;
    }




}