<?php

class User
{
    private $id;
    private $username;
    private $password;
    private $email;
    private $role;
    private $status;

    public function __construct($username, $password, $email, $role, $status="active", $id=null) {
        $this->id = $id;
        $this->username = $username;
        $this->password = $password;
        $this->email = $email;
        $this->role = $role;
        $this->status = $status;
    }

    public static function getAll() {
        $result = Connection::get("SELECT * FROM users WHERE NOT role = 'administrator'");

        $users = [];

        while ($row = $result->fetch_assoc()){
            $users []= new User(
                $row['username'],
                $row['password'],
                $row['email'],
                $row['role'],
                $row['status'],
                $row['id']
            );
        }

        return $users;
    }

    public static function getById($id){
        $sql = "SELECT * FROM users WHERE id = ?";
        $params = [$id];

        $result = Connection::getP($sql, $params);

        if (empty($result)) {
            return null;
        }

        $row = $result->fetch_assoc();

        return new User(
            $row['username'],
            $row['password'],
            $row['email'],
            $row['role'],
            $row['status'],
            $row['id']
        );
    }

    public function delete(){
        $sql = "DELETE FROM users WHERE id = ?";
        $params = [$this->id];
        Connection::setP($sql, $params);
    }

    public function blokiraj(){
        $sql = "UPDATE users SET status='blocked' WHERE id=?";
        $params = [$this->id];
        Connection::setP($sql, $params);
    }

    public function odblokiraj(){
        $sql = "UPDATE users SET status='active' WHERE id=?";
        $params = [$this->id];
        Connection::setP($sql, $params);
    }

    public static function register($username, $password, $email, $role) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $sql = "
            INSERT INTO users (username, password, email, role, status)
            VALUES (?, ?, ?, ?, 'active')
        ";

        $params = [$username, $hashedPassword, $email, $role];

        // Execute the prepared statement using setP function
        $success = Connection::setP($sql, $params);

        // Check if the user was successfully created and get the user data from the database
        if ($success) {
            return Message::success("korisnik uspesno dodat");
        }

        // Placeholder return value, replace this with actual logic
        return Message::danger("Doslo je do greske, molimo pokusajte kasnije");
    }

    public static function authenticateUser($username, $password){
        $sql = "SELECT * FROM users WHERE username = ?";
        $params = [$username];
        $result = Connection::getP($sql, $params);

        // Check if the user with the given username exists
        if ($result && $result->num_rows > 0) {
            $userData = $result->fetch_assoc();

            // Verify the password hash
            if (password_verify($password, $userData['password'])) {
                // Authentication successful, create session and return true
                return self::handleLogin(new User(
                    $userData['username'],
                    $userData['password'],
                    $userData['email'],
                    $userData['role'],
                    $userData['status'],
                    $userData['id']
                ));
            }
        }

        return Message::danger("korisnik nije pronadjen");
    }

    public static function isLoggedIn(){
        return isset($_SESSION["user"]);
    }

    public static function getCurrentUser(){
        $userSerialized = $_SESSION['user'];
        $user = unserialize($userSerialized);

        return $user;
    }

    public static function handleLogin($user) {
        if($user->getStatus()=="blocked"){
            return Message::danger("ovaj nalog je blokiran");
        }

        // Store user information in the session
        $_SESSION['user'] = serialize($user);

        // Perform redirect based on user role
        if ($user->getRole()==="korisnik") {
            header("Location: korisnik.php"); // Redirect to admin dashboard
        }else if ($user->getRole()==="umetnik") {
            header("Location: umetnik.php"); // Redirect to admin dashboard
        }else if ($user->getRole()==="administrator") {
            header("Location: administrator.php"); // Redirect to admin dashboard
        }

        exit();
    }

    /**
     * @return mixed|null
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed|null $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * @param mixed $username
     */
    public function setUsername($username)
    {
        $this->username = $username;
    }

    /**
     * @return mixed
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * @param mixed $password
     */
    public function setPassword($password)
    {
        $this->password = $password;
    }

    /**
     * @return mixed
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * @param mixed $email
     */
    public function setEmail($email)
    {
        $this->email = $email;
    }

    /**
     * @return mixed
     */
    public function getRole()
    {
        return $this->role;
    }

    /**
     * @param mixed $role
     */
    public function setRole($role)
    {
        $this->role = $role;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @param mixed $status
     */
    public function setStatus($status)
    {
        $this->status = $status;
    }


}