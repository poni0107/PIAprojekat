<?php

class Connection
{
    private $db_servername;
    private $db_username;
    private $db_password;
    private $db_database;

    public function __construct() {
        $this->db_servername = "localhost";
        $this->db_username = "root";
        $this->db_password = "";
        $this->db_database = "izlozba-slika";
    }

    public static function connection() {
        $obj = new Connection();
        $conn = new mysqli($obj->db_servername, $obj->db_username, $obj->db_password, $obj->db_database);
        $conn->set_charset("utf8");

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        return $conn;
    }

    public static function get($sql) {
        $conn = Connection::connection();
        $result = $conn->query($sql);
        $conn->close();
        return $result;
    }

    public static function getP($sql,$params = []) {
        $conn = Connection::connection();
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            if (!empty($params)) {
                $types = str_repeat('s', count($params));
                $stmt->bind_param($types, ...$params);
            }

            $stmt->execute();

            $result = $stmt->get_result();

            $stmt->close();
            $conn->close();

            return $result;
        } else {
            return null;
        }
    }

    public static function setP($sql, $params = []) {
        $conn = Connection::connection();
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            if (!empty($params)) {
                $types = str_repeat('s', count($params)); // Assuming all parameters are strings
                $stmt->bind_param($types, ...$params);
            }

            $success = $stmt->execute();

            $stmt->close();
            $conn->close();

            return $success;
        } else {
            echo $conn->error;
            return null;
        }
    }
}