<?php
$msg = "";

include_once("php/funkcije.php");

if(!User::isLoggedIn()){
    header("location: index.php");
    die();
}

$user = User::getCurrentUser();

if($user->getRole()!=="administrator"){
    header("location: index.php");
    die();
}

if(isset($_POST["registracija"])){
    $username = UserInput::sanitize($_POST["username"]);
    $password = UserInput::sanitize($_POST["password"]);
    $email = UserInput::sanitize($_POST["email"]);
    $role = UserInput::sanitize($_POST["role"]);

    $msg = User::register($username, $password, $email, $role);
}

if(isset($_POST["obrisi"])){
    $id = UserInput::sanitize($_POST["obrisi"]);
    $user = User::getById($id);
    $user->delete();
}

if(isset($_POST["blokiraj"])){
    $id = UserInput::sanitize($_POST["blokiraj"]);
    $user = User::getById($id);
    $user->blokiraj();
}

if(isset($_POST["odblokiraj"])){
    $id = UserInput::sanitize($_POST["odblokiraj"]);
    $user = User::getById($id);
    $user->odblokiraj();
}

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">

</head>
<body>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <?php include_once("php/navigacija.php"); ?>
        </div>
    </div>

    <div class="row">
        <div class="col-12 text-center">
            <?php echo $msg; ?>
        </div>
    </div>

    <div class="row">
        <div class="col-12 text-center">
            <?php
                $users = User::getAll();

            ?>

            <table class="table table-dark table-striped table-hover">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">username</th>
                    <th scope="col">email</th>
                    <th scope="col">role</th>
                    <th scope="col">status</th>
                    <th scope="col"></th>
                    <th scope="col"></th>
                </tr>
                </thead>
                <tbody>

                    <?php
                    foreach ($users as $user){
                        ?>
                    <tr>
                            <th scope="row"><?php echo $user->getId(); ?></th>
                            <td><?php echo $user->getUsername(); ?></td>
                            <td><?php echo $user->getEmail(); ?></td>
                            <td><?php echo $user->getRole(); ?></td>
                            <td class="<?php echo $user->getStatus(); ?>"><?php echo $user->getStatus(); ?></td>
                            <td>
                                <form action="administrator.php" method="post">
                                    <button type="submit" name="obrisi" value="<?php echo $user->getId(); ?>" class="btn btn-outline-danger">
                                        ukloni
                                    </button>
                                </form>
                            </td>
                            <td>
                                <?php
                                if($user->getStatus()!="blocked"){
                                    ?>
                                    <form action="administrator.php" method="post">
                                        <button type="submit" name="blokiraj" value="<?php echo $user->getId(); ?>" class="btn btn-outline-warning">
                                            blokiraj
                                        </button>
                                    </form>
                                    <?php
                                }else{
                                    ?>
                                    <form action="administrator.php" method="post">
                                        <button type="submit" name="odblokiraj" value="<?php echo $user->getId(); ?>" class="btn btn-outline-primary">
                                            odblokiraj
                                        </button>
                                    </form>
                                    <?php
                                }
                                ?>

                            </td>
                    </tr>
                        <?php
                    }
                    ?>


                </tbody>
            </table>
        </div>
    </div>

    <div class="row mt-5">
        <div class="col-6 offset-3">
            <h2>dodavanje korisnika</h2>
            <form method="post" action="administrator.php">
                <!-- Dodajte polja za unos podataka -->
                <div class="mb-3">
                    <label for="username" class="form-label">Korisničko ime:</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">Lozinka:</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">E-mail adresa:</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>

                <div class="mb-3">
                    <label for="role" class="form-label">Uloga:</label>
                    <select class="form-select" id="role" name="role" required>
                        <option value="korisnik">Korisnik</option>
                        <option value="umetnik">Umetnik</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary" name="registracija">dodaj</button>
            </form>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
